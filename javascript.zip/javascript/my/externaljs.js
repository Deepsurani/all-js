function btn1Click()
{
    lbl1.innerHTML = txt1.value;
}