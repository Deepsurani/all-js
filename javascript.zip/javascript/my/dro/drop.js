function btn1(){
    lbl1.innerHTML = drop1.value +"/" +drop2.value + "/" + drop3.value;
}