function btn1Click()
{
lbl1.innerHTML = txt1.value +"&nbsp&nbsp&nbsp&nbsp&nbsp"+txt2.value;
}