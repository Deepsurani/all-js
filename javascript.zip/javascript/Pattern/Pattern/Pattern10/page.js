
var a=1;

    for(let i=1; i<=4; i++)
    {
        for(let j=1; j<=i; j++)
        {
            lbl1.innerHTML += a++ +"&nbsp&nbsp";
        }
        lbl1.innerHTML +="<br><br>";
    }