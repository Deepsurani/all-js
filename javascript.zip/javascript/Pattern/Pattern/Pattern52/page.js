
    for(let i=1; i<=5; i++)
    {
        for(let j=i; j>=1; j--)
        {
            lbl1.innerHTML +=j % 2 +"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" ;  
        }
        lbl1.innerHTML +="<br> ";
    }