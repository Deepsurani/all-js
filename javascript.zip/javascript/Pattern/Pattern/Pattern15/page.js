
    for(let i=1; i<=4; i++)
    {
        for(let j=4; j>=i; j--)
        {
            lbl1.innerHTML +=i +"&nbsp&nbsp&nbsp";
        }
        lbl1.innerHTML +="<br><br>";
    }