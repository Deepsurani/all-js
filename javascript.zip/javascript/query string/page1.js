function btn1() {
    var t1 = txt1.value;
    window.location.href = "Page2.html?name="+t1;
}
function btn2() {
    var t1 = txt1.value
    var t2 = txt2.value
    window.location.href = "page2.html?name="+t1+"&email="+t2;
}